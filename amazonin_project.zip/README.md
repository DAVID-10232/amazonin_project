# Proyecto Big Data - Análisis de Tweets AMAZONIN

## Descripción
Pipeline simple de Big Data en Python que analiza 10k tweets de Amazon India.  
Incluye ingesta, limpieza, análisis de sentimiento y almacenamiento optimizado.

## Pasos para ejecutar
1. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
